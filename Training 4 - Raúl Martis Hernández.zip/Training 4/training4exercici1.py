for i in range(1,200): # Imprimeix els nombres parells entre 1 i 200
    if i % 2 == 0: # Comprova si el nombre és parell
        print(i) # Imprimeix el nombre parell
        
    